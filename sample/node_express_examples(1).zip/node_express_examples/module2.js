var salutation = 'Mr';
module.exports = function(name){
    console.log('Hello %s %s ',salutation,name);
}
 
//var module2 = require('./module2.js');
//salutation = 'Dear';
//module2('CreativeDev');
//salutation = 'Mr';
//module2('Robert');

