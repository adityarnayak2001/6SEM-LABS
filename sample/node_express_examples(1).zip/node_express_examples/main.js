'use strict';
var Person = require('./person');
var person = new Person('Bibek', 25);
console.log(person.get_name());